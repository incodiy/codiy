-- CREATE TABLE "base_postal_code" -----------------------------
CREATE TABLE `base_postal_code`( 
	`id` Int( 10 ) UNSIGNED AUTO_INCREMENT NOT NULL,
	`province` VarChar( 80 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
	`regency` VarChar( 100 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
	`sub_district` VarChar( 100 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
	`urban_village` VarChar( 100 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
	`postal_code` VarChar( 5 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
	PRIMARY KEY ( `id` ) )
CHARACTER SET = utf8
COLLATE = utf8_unicode_ci
ENGINE = InnoDB
AUTO_INCREMENT = 81249;
-- -------------------------------------------------------------
-- CREATE INDEX "base_postal_code_postal_code_index" -----------
CREATE INDEX `base_postal_code_postal_code_index` USING BTREE ON `base_postal_code`( `postal_code` );
-- -------------------------------------------------------------